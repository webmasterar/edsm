This is a C++ wrapper around [tabix
project](http://samtools.sourceforge.net/tabix.shtml) which abstracts some
of the details of opening and jumping in tabix-indexed files.

Author: Erik Garrison <erik.garrison@gmail.com>
